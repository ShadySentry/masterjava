package ru.javaops.masterjava.model;

/**
 * gkislin
 * 13.10.2016
 */
public enum UserFlag {
    active,
    deleted,
    superuser;
}
